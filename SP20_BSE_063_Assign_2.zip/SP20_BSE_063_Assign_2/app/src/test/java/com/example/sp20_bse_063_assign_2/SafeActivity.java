package com.example.sp20_bse_063_assign_2;

public class SafeActivity {
}
